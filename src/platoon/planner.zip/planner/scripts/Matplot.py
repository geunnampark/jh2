from matplotlib import pyplot as plt

plt.plot()

plt.show()